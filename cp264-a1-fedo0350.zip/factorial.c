/*
 -------------------------
 File: factorial.c
 Project: fedo0350_a01
 get factorial
 -------------------------
 Author: Noah Fedosoff
 ID: 200420350
 Email: fedo0350@mylaurier.ca
 Version 2022-01-16
 -------------------------
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *args[]) {
	int i, n = 0, f = 1, prev, is_overflow = 0, calc = 0;

	if (argc > 1) {
		n = atoi(args[1]);  // convert command line argument to an integer

		if (n >= 1) {

			for (int i = 1; i <= n; i++) {
				if (i == 1) {
					prev = 1;
					printf("%11d", prev);
				} else {
					calc = i * prev;
					if (prev != calc / i) {
						printf("\n overflow at %i!", i);
						break;
					}
					prev = calc;
					printf("%11d", calc);
				}
				if (i % 4 == 0) {
					printf("\n");
				}

			}

		} else {
			printf("%s:invalid argument\n", args[1]);
		}
	} else {
		printf("no argument");
	}
	return 0;
}
