/*
 -------------------------
 File: quadratic.c
 Project: fedo0350_a01
 find quadratic roots
 -------------------------
 Author: Noah Fedosoff
 ID: 200420350
 Email: fedo0350@mylaurier.ca
 Version 2022-01-16
 -------------------------
 */
#include <stdio.h>
#include <math.h>  // need this library for maths functions fabs() and sqrt()

#define EPSILON 0.000001
// or #define EPSILON 1e-6

int main() {
	// setbuf(stdout, NULL); // uncomment this line for using Eclipse console

	float a, b, c, d, x1, x2;
	int inn;
	char temp;

	do { // do-while for new input problem

		do { // do-while loop to get correct input of three floating numbers

			printf("\nPlease enter the coefficients a,b,c\n");
			inn = scanf("%f,%f,%f", &a, &b, &c);

			if (inn != 3) {
				printf("input:Invalid input\n");
			} else
				break;

			do {  // flush the input buffer
				scanf("%c", &temp);
				if (temp == '\n')
					break;
			} while (1);

		} while (1);

		if (fabs(a) < EPSILON && fabs(b) < EPSILON && fabs(c) < EPSILON) {
			printf("input:quit\n");
			break;

		} else if (fabs(a) < EPSILON) {
			printf("input:not a quadratic equation\n");

		} else {

			d = b * b - 4 * a * c;

			if (d == 0) {
				printf("The equation has two equal real roots\n");
				x1 = -b / (2 * a);
				printf("x1: %f", x1);
			} else if (d < 0) {
				printf("The equation has two complex roots\n");
				x1 = -b / (2 * a);
				x2 = sqrt(-d) / (2 * a);
				printf("real: %f\n", x1);
				printf("imaginary: %f\n", x2);

			} else {
				printf("The equation has two distinct real roots\n");
				x1 = (-b + sqrt(d)) / (2 * a);
				x2 = (-b - sqrt(d)) / (2 * a);
				printf("x1: %f\n", x1);
				printf("x2: %f\n", x2);
			}

		}
	} while (1);
	return 0;
}
