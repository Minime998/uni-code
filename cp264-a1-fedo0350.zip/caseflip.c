/*
 -------------------------
 File: caseflip.c
 Project: fedo0350_a01
 case flip letters and digits
 -------------------------
 Author: Noah Fedosoff
 ID: 200420350
 Email: fedo0350@mylaurier.ca
 Version 2022-01-16
 -------------------------
 */

#include <stdio.h>
#include <ctype.h>
int main() {

	char chr = 0, temp;

	do {

		printf("\nPlease enter a character\n");
		scanf("%c", &chr);

		// flush the input buffer
		do { // this loop is to get rid of additional characters in stdin buffer
			scanf("%c", &temp);
			if (temp == '\n')
				break;
		} while (1);
		if (isalpha(chr)) {
			if (isalpha(chr) == 2) {
				temp = toupper(chr);
				printf("%c:%i,%c", chr, chr, temp);
			} else if (isalpha(chr) == 1) {
				temp = tolower(chr);
				printf("%c:%i,%c", chr, chr, temp);
			}
		}
		if (isdigit(chr)) {
			int d = (int) (chr);
			int asc = (chr - 48) * (chr - 48);
			printf("%c:%i,%i", chr, chr, asc);
		}

		else if (chr == '*') {
			break;
		}

		else if (isdigit(chr) == 0 && isalpha(chr) == 0) {
			printf("%c:invalid", chr);
		}

	} while (1);
	printf("%c:quit\n", chr);
	return 0;
}
