/*
 -------------------------
 File: File Name
 Project: Project name
 -------------------------
 Author: Noah Fedosoff
 ID: 200420350
 Email: fedo0350@mylaurier.ca
 Version YYYY-MM-DD
 -------------------------
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "heap.h"

HEAP* new_heap(int capacity) {

}

void insert(HEAP *heap, HNODE new_node) {

}

HNODE extract_min(HEAP *heap) {
// your implementation
}

int change_key(HEAP *heap, int index, KEYTYPE new_key) {
// your implementation

}

int find_data_index(HEAP *heap, DATA data) {
// your implementation
}

int cmp(KEYTYPE a, KEYTYPE b) {
// your implementation
}

