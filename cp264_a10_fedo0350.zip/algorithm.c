/*
 -------------------------
 File: File Name
 Project: Project name
 -------------------------
 Author: Noah Fedosoff
 ID: 200420350
 Email: fedo0350@mylaurier.ca
 Version YYYY-MM-DD
 -------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include "heap.h"
#include "algorithm.h"

EDGELIST* mst_prim(GRAPH *g, int start) {

}

EDGELIST* spt_dijkstra(GRAPH *g, int start) {
// your implementation
}

EDGELIST* sp_dijkstra(GRAPH *g, int start, int end) {
// your implementation
}
