Name: Noah Fedosoff
ID: 200420350
Email: fedo0350@mylaurier.ca
WorkID: CP264-a3
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Evaluation grid: [self-evaluation/total/marker-evaluation]

A3

Q1 My string functions
Q1.1 str_length()                         [3/3/*]
Q1.2 word_count()                         [4/4/*]
Q1.3 lower_case()                         [3/3/*]
Q1.4 trim()                               [5/5/*]

Q2 My word processor
Q2.1 Data structures                      [4/4/*]
Q2.2 process_word(()                      [6/6/*]
Q2.3 save_to_file()                       [5/5/*]

Total:                                    [30/30/*]

Copy and paste the console output of your public test in the following. This will help markers to evaluate your program if it fails the marking testing.  

Q1 output:
str:"     This Is    a Test   "
str_length(str):25
word_count(str):4
trim(str):"this is a test"
str_length(trim(str)):14


Q2 output:

C:\Users\noahf\Documents\workspaces\cp216\fedo0350_a03\src>q2
word processing:done
line count:2
word count:10
distinct word count:6
this:2
is:2
the:2
first:1
test:2
second:1
saving result to file:done